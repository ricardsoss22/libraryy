<?php
include('connect.php');
session_start();
include 'header.php';
include('navbar.php');?>
    <!-- login area start -->
    <div class="login-area">
        <div class="container">
            <div class="login-box ptb--100"> 
            	<form name="login_form" method="post" style="width: 850px;""> 
        <div style="font-size: 20px; padding: 5%;">
        Name : <b>Nikhil Bhalerao</b><br>
				Email : <b>ndbhalerao91@gmail.com</b><br>
				Contact : <b>+919423979339</b><br>
				Address  : <b>MH, India</b><br><br>
				Experience : <b>I am a Programmer having Experty in languages like PHP, Codeignitor, Laravel, and Android. having 6 years+ Experience. love to work with programming and various logics behind it.</b><br><br>
				Note : <b>
For students or anyone else who needs program or source code for thesis writing or any Professional Software Development, Website Development, Mobile Apps Development at affordable cost.</b><br>
				</div>

    </form>
            </div>
        </div>
    </div>
    <!-- login area end -->
    <?php include('footer.php');?>